const mathlib = require('./mathlib')();

console.log(mathlib.add(2,3));
console.log(mathlib.multiply(2,3));
console.log(mathlib.square(5));
console.log(mathlib.random(1, 25));
