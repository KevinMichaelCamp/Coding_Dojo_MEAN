module.exports = {

  cats_function: function(req, res){
    res.render('cats')
  }

}
