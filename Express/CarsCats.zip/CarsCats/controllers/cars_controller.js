module.exports = {

  cars_function: function(req, res){
    res.render('cars');
  }
}
