module.exports = {

  new_function: function(req, res){
    res.render('new')
  }

}
