module.exports = {

  index_function: function(req, res){
    res.render('index');
  }

}
